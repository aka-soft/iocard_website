$(document).ready(function(){
    $(".navopener").click(function(){
        $(".hd-box nav").slideToggle();
    });
});
$(document).ready(function(){
	$('.navopener').click(function(){
		$('.navopener .fa-bars').toggleClass('fa-window-close');
	});
});

